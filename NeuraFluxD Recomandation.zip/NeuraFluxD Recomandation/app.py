import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics.pairwise import cosine_similarity
import pickle

# Sample dataset (replace this with your actual dataset)
df = pd.read_csv('dataset.csv')

# Step 1: Encode the categorical features (Domain, Type)
x_col = ['Domain', 'Type']
encoder = OneHotEncoder(handle_unknown='ignore')
encoded_skills = encoder.fit_transform(df[x_col])

# Step 2: Scale numerical features (Price)
numerical_columns = ['Price']
scaler = StandardScaler()
scaled_numerical = scaler.fit_transform(df[numerical_columns])

# Step 3: Combine encoded categorical and numerical features
features = np.hstack((encoded_skills.toarray(), scaled_numerical))

# Load the pre-trained KMeans model
with open('model.pkl', 'rb') as model_file:
    kmeans_model = pickle.load(model_file)

# Function to recommend projects based on cluster prediction
def recommend_projects(domain, freelancer_type, budget=None, top_n=5):
    """
    Recommends projects based on the user's domain expertise, freelancer type, and optional budget constraints.
    """
    # Step 1: Prepare user input for domain and type (matching the encoder used in training)
    user_data = pd.DataFrame({'Domain': domain, 'Type': [freelancer_type] * len(domain)})
    user_skill_vector = encoder.transform(user_data)  # Ensure same encoder as training

    # Step 2: Handle budget and numerical features
    user_budget = budget if budget else df['Price'].mean()
    user_numerical_features = np.array([[user_budget]])
    user_numerical_features_scaled = scaler.transform(user_numerical_features)  # Ensure same scaler

    # Step 3: Combine encoded and scaled features
    user_features = np.hstack((user_skill_vector.toarray(), user_numerical_features_scaled))

    # Step 4: Compute cosine similarity
    similarities = cosine_similarity(features, user_features).flatten()  # Calculate cosine similarity
    df['SimilarityScore'] = similarities  # Add similarity scores to the DataFrame

    # Step 5: Filter projects by budget, if specified
    if budget:
        matching_projects = df[df['Price'] <= budget]  # Only include projects within budget
    else:
        matching_projects = df  # Include all projects

    # Step 6: Sort by similarity score and select top recommendations
    recommendations = matching_projects.sort_values(by='SimilarityScore', ascending=False).head(top_n)

    return recommendations  # Return all information about the recommended projects

# Streamlit UI
st.title("Project Recommendation System")

# User input for domain and freelancer type
domain = st.multiselect("Select your Domain(s)", options=df['Domain'].unique())
freelancer_type = st.selectbox("Select Freelancer Type", options=['hourly', 'fixed__price']) 
budget = st.number_input("Enter your budget (optional)", min_value=0.0, value=None)

# Recommendation button
if st.button('Get Recommendations'):
    if domain:
        recommendations = recommend_projects(domain, freelancer_type, budget)
        st.write("Top Project Recommendations:")
        st.dataframe(recommendations)
    else:
        st.warning("Please select at least one domain.")
